<?php
$koneksi=mysqli_connect('localhost','root','','db_inventoris');
if(!$koneksi){
	echo "Gagal konek!";
}
?>